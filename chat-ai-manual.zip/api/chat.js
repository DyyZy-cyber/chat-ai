// Ganti langsung di sini kalau mau pakai API key & model lain
const HF_API_KEY = "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";
const MODEL_ID = "mradermacher/Nusantara-1.8b-Indo-Chat";

export default async function handler(req, res) {
  if (req.method !== "POST") {
    return res.status(405).json({ error: "Method not allowed" });
  }

  const { message } = req.body;

  try {
    const response = await fetch(
      `https://api-inference.huggingface.co/models/${MODEL_ID}`,
      {
        method: "POST",
        headers: {
          Authorization: `Bearer ${HF_API_KEY}`,
          "Content-Type": "application/json",
        },
        body: JSON.stringify({ inputs: message }),
      }
    );

    const data = await response.json();
    const reply = data[0]?.generated_text || "⚠️ Tidak ada balasan";

    res.status(200).json({ reply });
  } catch (err) {
    res.status(500).json({ error: "Error dari API" });
  }
}